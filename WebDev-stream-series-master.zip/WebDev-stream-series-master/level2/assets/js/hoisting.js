//hoisting:
x = "asdasdasd";
console.log(x);
var x;
